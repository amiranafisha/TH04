﻿namespace WindowsFormsApp7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_SoccerTeamList = new System.Windows.Forms.Label();
            this.lb_TeamCity = new System.Windows.Forms.Label();
            this.lb_TeamCountry = new System.Windows.Forms.Label();
            this.lb_TeamName = new System.Windows.Forms.Label();
            this.lb_AddingTeam = new System.Windows.Forms.Label();
            this.lb_ChooseTeam = new System.Windows.Forms.Label();
            this.lb_ChooseCountry = new System.Windows.Forms.Label();
            this.comboBox_ChooseCountry = new System.Windows.Forms.ComboBox();
            this.comboBox_ChooseTeam = new System.Windows.Forms.ComboBox();
            this.textBox_TeamName = new System.Windows.Forms.TextBox();
            this.textBox_TeamCity = new System.Windows.Forms.TextBox();
            this.textBox_TeamCountry = new System.Windows.Forms.TextBox();
            this.lb_AddingPlayers = new System.Windows.Forms.Label();
            this.lb_PlayerNumber = new System.Windows.Forms.Label();
            this.lb_PlayerPosition = new System.Windows.Forms.Label();
            this.lb_PlayerName = new System.Windows.Forms.Label();
            this.textBox_PlayerNumber = new System.Windows.Forms.TextBox();
            this.textBox_PlayerName = new System.Windows.Forms.TextBox();
            this.comboBox_PlayerPosition = new System.Windows.Forms.ComboBox();
            this.btn_AddAddingPlayer = new System.Windows.Forms.Button();
            this.btn_AddAddingTeam = new System.Windows.Forms.Button();
            this.listBox_ListOfPlayer = new System.Windows.Forms.ListBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_SoccerTeamList
            // 
            this.lb_SoccerTeamList.AutoSize = true;
            this.lb_SoccerTeamList.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_SoccerTeamList.Location = new System.Drawing.Point(7, 17);
            this.lb_SoccerTeamList.Name = "lb_SoccerTeamList";
            this.lb_SoccerTeamList.Size = new System.Drawing.Size(153, 21);
            this.lb_SoccerTeamList.TabIndex = 0;
            this.lb_SoccerTeamList.Text = "Soccer Team List";
            // 
            // lb_TeamCity
            // 
            this.lb_TeamCity.AutoSize = true;
            this.lb_TeamCity.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TeamCity.Location = new System.Drawing.Point(381, 182);
            this.lb_TeamCity.Name = "lb_TeamCity";
            this.lb_TeamCity.Size = new System.Drawing.Size(102, 21);
            this.lb_TeamCity.TabIndex = 1;
            this.lb_TeamCity.Text = "Team City:";
            // 
            // lb_TeamCountry
            // 
            this.lb_TeamCountry.AutoSize = true;
            this.lb_TeamCountry.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TeamCountry.Location = new System.Drawing.Point(381, 117);
            this.lb_TeamCountry.Name = "lb_TeamCountry";
            this.lb_TeamCountry.Size = new System.Drawing.Size(133, 21);
            this.lb_TeamCountry.TabIndex = 2;
            this.lb_TeamCountry.Text = "Team Country:";
            // 
            // lb_TeamName
            // 
            this.lb_TeamName.AutoSize = true;
            this.lb_TeamName.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TeamName.Location = new System.Drawing.Point(381, 60);
            this.lb_TeamName.Name = "lb_TeamName";
            this.lb_TeamName.Size = new System.Drawing.Size(115, 21);
            this.lb_TeamName.TabIndex = 3;
            this.lb_TeamName.Text = "Team Name:";
            // 
            // lb_AddingTeam
            // 
            this.lb_AddingTeam.AutoSize = true;
            this.lb_AddingTeam.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_AddingTeam.Location = new System.Drawing.Point(474, 12);
            this.lb_AddingTeam.Name = "lb_AddingTeam";
            this.lb_AddingTeam.Size = new System.Drawing.Size(121, 21);
            this.lb_AddingTeam.TabIndex = 4;
            this.lb_AddingTeam.Text = "Adding Team";
            // 
            // lb_ChooseTeam
            // 
            this.lb_ChooseTeam.AutoSize = true;
            this.lb_ChooseTeam.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ChooseTeam.Location = new System.Drawing.Point(7, 127);
            this.lb_ChooseTeam.Name = "lb_ChooseTeam";
            this.lb_ChooseTeam.Size = new System.Drawing.Size(127, 21);
            this.lb_ChooseTeam.TabIndex = 5;
            this.lb_ChooseTeam.Text = "Choose Team:";
            // 
            // lb_ChooseCountry
            // 
            this.lb_ChooseCountry.AutoSize = true;
            this.lb_ChooseCountry.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ChooseCountry.Location = new System.Drawing.Point(7, 56);
            this.lb_ChooseCountry.Name = "lb_ChooseCountry";
            this.lb_ChooseCountry.Size = new System.Drawing.Size(147, 21);
            this.lb_ChooseCountry.TabIndex = 6;
            this.lb_ChooseCountry.Text = "Choose Country:";
            // 
            // comboBox_ChooseCountry
            // 
            this.comboBox_ChooseCountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChooseCountry.FormattingEnabled = true;
            this.comboBox_ChooseCountry.Location = new System.Drawing.Point(175, 56);
            this.comboBox_ChooseCountry.Name = "comboBox_ChooseCountry";
            this.comboBox_ChooseCountry.Size = new System.Drawing.Size(180, 28);
            this.comboBox_ChooseCountry.TabIndex = 7;
            this.comboBox_ChooseCountry.SelectedIndexChanged += new System.EventHandler(this.comboBox_ChooseCountry_SelectedIndexChanged);
            // 
            // comboBox_ChooseTeam
            // 
            this.comboBox_ChooseTeam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ChooseTeam.FormattingEnabled = true;
            this.comboBox_ChooseTeam.Location = new System.Drawing.Point(175, 120);
            this.comboBox_ChooseTeam.Name = "comboBox_ChooseTeam";
            this.comboBox_ChooseTeam.Size = new System.Drawing.Size(180, 28);
            this.comboBox_ChooseTeam.TabIndex = 8;
            this.comboBox_ChooseTeam.SelectedIndexChanged += new System.EventHandler(this.comboBox_ChooseTeam_SelectedIndexChanged);
            // 
            // textBox_TeamName
            // 
            this.textBox_TeamName.Location = new System.Drawing.Point(530, 60);
            this.textBox_TeamName.Name = "textBox_TeamName";
            this.textBox_TeamName.Size = new System.Drawing.Size(148, 26);
            this.textBox_TeamName.TabIndex = 9;

            // 
            // textBox_TeamCity
            // 
            this.textBox_TeamCity.Location = new System.Drawing.Point(530, 182);
            this.textBox_TeamCity.Name = "textBox_TeamCity";
            this.textBox_TeamCity.Size = new System.Drawing.Size(148, 26);
            this.textBox_TeamCity.TabIndex = 10;
            // 
            // textBox_TeamCountry
            // 
            this.textBox_TeamCountry.Location = new System.Drawing.Point(530, 115);
            this.textBox_TeamCountry.Name = "textBox_TeamCountry";
            this.textBox_TeamCountry.Size = new System.Drawing.Size(148, 26);
            this.textBox_TeamCountry.TabIndex = 11;
            // 
            // lb_AddingPlayers
            // 
            this.lb_AddingPlayers.AutoSize = true;
            this.lb_AddingPlayers.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_AddingPlayers.Location = new System.Drawing.Point(785, 17);
            this.lb_AddingPlayers.Name = "lb_AddingPlayers";
            this.lb_AddingPlayers.Size = new System.Drawing.Size(135, 21);
            this.lb_AddingPlayers.TabIndex = 12;
            this.lb_AddingPlayers.Text = "Adding Players";
            // 
            // lb_PlayerNumber
            // 
            this.lb_PlayerNumber.AutoSize = true;
            this.lb_PlayerNumber.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PlayerNumber.Location = new System.Drawing.Point(710, 122);
            this.lb_PlayerNumber.Name = "lb_PlayerNumber";
            this.lb_PlayerNumber.Size = new System.Drawing.Size(139, 21);
            this.lb_PlayerNumber.TabIndex = 13;
            this.lb_PlayerNumber.Text = "Player Number:";
            // 
            // lb_PlayerPosition
            // 
            this.lb_PlayerPosition.AutoSize = true;
            this.lb_PlayerPosition.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PlayerPosition.Location = new System.Drawing.Point(710, 182);
            this.lb_PlayerPosition.Name = "lb_PlayerPosition";
            this.lb_PlayerPosition.Size = new System.Drawing.Size(140, 21);
            this.lb_PlayerPosition.TabIndex = 14;
            this.lb_PlayerPosition.Text = "Player Position:";
            // 
            // lb_PlayerName
            // 
            this.lb_PlayerName.AutoSize = true;
            this.lb_PlayerName.Font = new System.Drawing.Font("Mongolian Baiti", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PlayerName.Location = new System.Drawing.Point(710, 65);
            this.lb_PlayerName.Name = "lb_PlayerName";
            this.lb_PlayerName.Size = new System.Drawing.Size(121, 21);
            this.lb_PlayerName.TabIndex = 15;
            this.lb_PlayerName.Text = "Player Name:";
            // 
            // textBox_PlayerNumber
            // 
            this.textBox_PlayerNumber.Location = new System.Drawing.Point(868, 117);
            this.textBox_PlayerNumber.Name = "textBox_PlayerNumber";
            this.textBox_PlayerNumber.Size = new System.Drawing.Size(148, 26);
            this.textBox_PlayerNumber.TabIndex = 16;
            // 
            // textBox_PlayerName
            // 
            this.textBox_PlayerName.Location = new System.Drawing.Point(868, 65);
            this.textBox_PlayerName.Name = "textBox_PlayerName";
            this.textBox_PlayerName.Size = new System.Drawing.Size(148, 26);
            this.textBox_PlayerName.TabIndex = 17;
            // 
            // comboBox_PlayerPosition
            // 
            this.comboBox_PlayerPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_PlayerPosition.FormattingEnabled = true;
            this.comboBox_PlayerPosition.Location = new System.Drawing.Point(868, 182);
            this.comboBox_PlayerPosition.Name = "comboBox_PlayerPosition";
            this.comboBox_PlayerPosition.Size = new System.Drawing.Size(154, 28);
            this.comboBox_PlayerPosition.TabIndex = 18;
            // 
            // btn_AddAddingPlayer
            // 
            this.btn_AddAddingPlayer.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_AddAddingPlayer.Location = new System.Drawing.Point(868, 241);
            this.btn_AddAddingPlayer.Name = "btn_AddAddingPlayer";
            this.btn_AddAddingPlayer.Size = new System.Drawing.Size(89, 42);
            this.btn_AddAddingPlayer.TabIndex = 19;
            this.btn_AddAddingPlayer.Text = "Add";
            this.btn_AddAddingPlayer.UseVisualStyleBackColor = false;
            this.btn_AddAddingPlayer.Click += new System.EventHandler(this.btn_AddAddingPlayer_Click);
            // 
            // btn_AddAddingTeam
            // 
            this.btn_AddAddingTeam.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_AddAddingTeam.Location = new System.Drawing.Point(385, 241);
            this.btn_AddAddingTeam.Name = "btn_AddAddingTeam";
            this.btn_AddAddingTeam.Size = new System.Drawing.Size(89, 42);
            this.btn_AddAddingTeam.TabIndex = 20;
            this.btn_AddAddingTeam.Text = "Add";
            this.btn_AddAddingTeam.UseVisualStyleBackColor = false;
            this.btn_AddAddingTeam.Click += new System.EventHandler(this.btn_AddAddingTeam_Click);
            // 
            // listBox_ListOfPlayer
            // 
            this.listBox_ListOfPlayer.FormattingEnabled = true;
            this.listBox_ListOfPlayer.ItemHeight = 20;
            this.listBox_ListOfPlayer.Location = new System.Drawing.Point(11, 191);
            this.listBox_ListOfPlayer.Name = "listBox_ListOfPlayer";
            this.listBox_ListOfPlayer.Size = new System.Drawing.Size(343, 164);
            this.listBox_ListOfPlayer.TabIndex = 21;
            // 
            // btn_Remove
            // 
            this.btn_Remove.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Remove.Location = new System.Drawing.Point(12, 377);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(89, 42);
            this.btn_Remove.TabIndex = 22;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = false;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1115, 450);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.listBox_ListOfPlayer);
            this.Controls.Add(this.btn_AddAddingTeam);
            this.Controls.Add(this.btn_AddAddingPlayer);
            this.Controls.Add(this.comboBox_PlayerPosition);
            this.Controls.Add(this.textBox_PlayerName);
            this.Controls.Add(this.textBox_PlayerNumber);
            this.Controls.Add(this.lb_PlayerName);
            this.Controls.Add(this.lb_PlayerPosition);
            this.Controls.Add(this.lb_PlayerNumber);
            this.Controls.Add(this.lb_AddingPlayers);
            this.Controls.Add(this.textBox_TeamCountry);
            this.Controls.Add(this.textBox_TeamCity);
            this.Controls.Add(this.textBox_TeamName);
            this.Controls.Add(this.comboBox_ChooseTeam);
            this.Controls.Add(this.comboBox_ChooseCountry);
            this.Controls.Add(this.lb_ChooseCountry);
            this.Controls.Add(this.lb_ChooseTeam);
            this.Controls.Add(this.lb_AddingTeam);
            this.Controls.Add(this.lb_TeamName);
            this.Controls.Add(this.lb_TeamCountry);
            this.Controls.Add(this.lb_TeamCity);
            this.Controls.Add(this.lb_SoccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_SoccerTeamList;
        private System.Windows.Forms.Label lb_TeamCity;
        private System.Windows.Forms.Label lb_TeamCountry;
        private System.Windows.Forms.Label lb_TeamName;
        private System.Windows.Forms.Label lb_AddingTeam;
        private System.Windows.Forms.Label lb_ChooseTeam;
        private System.Windows.Forms.Label lb_ChooseCountry;
        private System.Windows.Forms.ComboBox comboBox_ChooseCountry;
        private System.Windows.Forms.ComboBox comboBox_ChooseTeam;
        private System.Windows.Forms.TextBox textBox_TeamName;
        private System.Windows.Forms.TextBox textBox_TeamCity;
        private System.Windows.Forms.TextBox textBox_TeamCountry;
        private System.Windows.Forms.Label lb_AddingPlayers;
        private System.Windows.Forms.Label lb_PlayerNumber;
        private System.Windows.Forms.Label lb_PlayerPosition;
        private System.Windows.Forms.Label lb_PlayerName;
        private System.Windows.Forms.TextBox textBox_PlayerNumber;
        private System.Windows.Forms.TextBox textBox_PlayerName;
        private System.Windows.Forms.ComboBox comboBox_PlayerPosition;
        private System.Windows.Forms.Button btn_AddAddingPlayer;
        private System.Windows.Forms.Button btn_AddAddingTeam;
        private System.Windows.Forms.ListBox listBox_ListOfPlayer;
        private System.Windows.Forms.Button btn_Remove;
    }
}

